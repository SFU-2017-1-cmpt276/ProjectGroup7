//
//  MenuViewController.swift
//  test
//
//  Created by Grazietta Hof on 2017-03-01.
//  Copyright © 2017 cmpt276. All rights reserved.
//

import UIKit

class MenuViewController: UIViewController {
    
   
   
    
    
    // var array: NSMutableArray! = NSMutableArray()

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    
    

}
